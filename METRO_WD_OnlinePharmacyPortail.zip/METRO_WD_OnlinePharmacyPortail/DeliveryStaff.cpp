#include<iostream>
#include "DeliveryStaff.h"

DeliveryStaff::DeliveryStaff()
{
}

void DeliveryStaff::setDeliveryDetails(int oID, float bil, float ddist, float chardist, float tot){
	orderID = oID;
	Bill = bil;
	deliDistance = ddist;
	chargrforDistance = chardist;
	total = tot;
}

void DeliveryStaff::displayDeliveryDetails(){
}

DeliveryStaff: ~DeliveryStaff()

