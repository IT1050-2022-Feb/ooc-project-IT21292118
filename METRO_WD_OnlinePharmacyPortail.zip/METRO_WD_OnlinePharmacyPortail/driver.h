#include "Employee.h"
#include "DeliveryStaff.h"

class driver
{
	private:
		int orderID;
		
	public:
	    void receiveDeliveryDetails();
		void updateDeliveryDetails();
		~driver();	
};
