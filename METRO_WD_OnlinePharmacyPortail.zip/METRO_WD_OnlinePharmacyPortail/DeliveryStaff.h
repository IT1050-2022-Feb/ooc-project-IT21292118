#include "orders.h"
#include "systemadministrator.h"
#include "driver.h"

class DeliveryStaff
{
	private:
		int orderID;
		float Bill;
		float deliDistance;
		float chargrforDistance;
		float total;
		
	public:
	    void setDeliveryDetails(int oID, float bil, float ddist, float chardist, float tot);
	    void displayDeliveryDetails();  
        ~DeliveryStaff();	
};
